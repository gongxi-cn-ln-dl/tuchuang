#include<bits/stdc++.h>
using namespace std;

int A[1005];
int p = 1;
void push(int a){A[p++] = a;}
void pop(){p--;}
int top(){return A[p-1];}

int B[1005];

int main(){
	int n;
	scanf("%d",&n);
	memset(A,0,sizeof(A));
	for(int i = 0;i<n;i++) scanf("%d",&B[i]);
	int cur = 1;
	for(int i = 0;i<n;i++){
		while(cur<=B[i]){
			push(cur++);
		}
		if(top() == B[i]) pop();
		else{
			printf("NO");
			return 0;
		}
	}
	printf("YES");
	return 0;
}
