#include<bits/stdc++.h>
using namespace std;

int queue_[100100];
int head_ = 0;
int tail_ = 0;
void push(int a){
	queue_[tail_++] = a;
}
void pop(){
	head_++;
}
int front(){
	return queue_[head_];
}
int main(){
	int n;
	scanf("%d",&n);
	for(int i = 0;i<n;i++){
		int t,c;
		scanf("%d",&t);
		if(t == 1){scanf("%d",&c);push(c);}
		if(t == 2){pop();}
		if(t == 3){printf("%d\n",front());}
	}
	return 0;
}
