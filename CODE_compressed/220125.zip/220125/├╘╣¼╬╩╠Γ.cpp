#include<bits/stdc++.h>
using namespace std;

int A[12][12];
int B[12][12];

int n;
int cnt = 0;

void Search(int x,int y){
	if(B[x][y] || A[x][y]) return;
	if(x == 1 && y == n){
		cnt++;
		return;
	}
	B[x][y] = 1;
	Search(x+1,y+1);
	Search(x+1,y);
	Search(x+1,y-1);
	Search(x,y+1);
	Search(x,y-1);
	Search(x-1,y+1);
	Search(x-1,y);
	Search(x-1,y-1);
	B[x][y] = 0;
}
int main(){
	for(int i = 0;i<12;i++){
		for(int j = 0;j<12;j++){
			A[i][j] = 1;
			B[i][j] = 1;
		}
	}
	scanf("%d",&n);
	for(int i = 1;i<=n;i++){
		for(int j = 1;j<=n;j++){
			scanf("%d",&A[i][j]);
			B[i][j] = A[i][j];
		}
	}
	Search(1,1);
	printf("%d",cnt);
	return 0;
}
