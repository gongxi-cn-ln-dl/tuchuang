#include<bits/stdc++.h>
using namespace std;

int main(){
	int n,m;
	scanf("%d%d",&n,&m); 
	bool A[150];
	for(int i = 0;i<n;i++){
		A[i] = 1;
	} 
	int x = m-1;
	while(n){
		if(!A[x]){
			x = (x+1)%n;
			continue;
		}
		A[x] = 0;
		printf("%d ",x+1);
		x = (x+m)%n;
		n--;
	}
	return 0;
}
