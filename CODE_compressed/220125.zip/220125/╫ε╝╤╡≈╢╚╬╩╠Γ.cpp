#include<bits/stdc++.h>
using namespace std;

int n,k;
int A[101];
int B[1001];
int sumM = 1e9;

void find(int x,int sum){
	if(sum >= sumM) return;
	if(x > n){
		if(sum < sumM) sumM = sum;
		return;
	}
	
	for(int i = 1;i<=k;i++){
		if(B[i] + A[x] >= sumM) continue;
		B[i] = B[i]+A[x];
		find(x+1,max(sum,B[i]));
		B[i] = B[i]-A[x];
	}
	
}

int main(){
	scanf("%d%d",&n,&k);
	for(int i = 1;i<=n;i++){
		scanf("%d",&A[i]);
	}
	memset(B,0,sizeof(B));
	find(1,0);
	printf("%d",sumM);
	return 0;
}
