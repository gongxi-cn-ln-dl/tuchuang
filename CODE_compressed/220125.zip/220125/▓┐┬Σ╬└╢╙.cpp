#include<bits/stdc++.h>
using namespace std;

int cd[3050][3050];
int haveCd[3050];
int A[3050];

int ma = -1;
int fa[3050];
int B[3050][3050];

int n;

bool hc(int x){
	for(int i = 1;i<x;i++){
		if(A[i] == 1 && cd[i][x] == 1) return true;
	}
	return false;
}

void Search(int k,int sum){
	if(k > n){
		if(sum <= ma) return;
		ma = sum;
		for(int i = 1;i<=n;i++) fa[i] = A[i];
		return;
	}

	if(!hc(k)){
		A[k] = 1;
		Search(k+1,sum+1);
		A[k] = 0;
	}
	Search(k+1,sum);
}

int main(){
	int m;
	scanf("%d%d",&n,&m);
	for(int i = 0;i<m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		cd[u][v] = 1;
		cd[v][u] = 1;
	}
	
	Search(1,0);
	printf("%d\n",ma);
	for(int i = 1;i<=n;i++){
		printf("%d ",fa[i]);
	}
	return 0;
}
//7 10
//1 2
//1 4
//2 4
//2 3
//2 5
//2 6
//3 5
//3 6
//4 5
//5 6
