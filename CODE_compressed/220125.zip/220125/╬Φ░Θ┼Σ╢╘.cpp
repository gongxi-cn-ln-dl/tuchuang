#include<bits/stdc++.h>
using namespace std;

int A[10001];
int B[10001];
int k1 = 1,k;
int r1,r2;
int f1 = 1;
int f2 = 1;

int main(){
	int m,n,k;
	scanf("%d%d%d",&m,&n,&k);
	for(int i = 1;i<=m;i++) A[i] = i;
	for(int i = 1;i<=n;i++) B[i] = i;
	r1 = m;
	r2 = n;
	while(k1<=k){
		printf("%d %d\n",A[f1],B[f2]);
		r1++;A[r1] = A[f1];f1++;
		r2++;B[r2] = B[f2];f2++;
		k1++;
	}
	return 0;
}
