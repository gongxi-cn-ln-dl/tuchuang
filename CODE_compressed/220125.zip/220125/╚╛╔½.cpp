#include<bits/stdc++.h>
using namespace std;

int cd[3050][3050];
int A[3050];

int ma = 0;
int B[3050];

int n,m;

bool hc(int x){
	for(int i = 1;i<x;i++){
		if(A[i] == 1 && cd[i][x] == 1){
			if(B[x] == B[i]) return true;
		} 
	}
	//��һ����Ⱦɫ�ĵ����� 
	return false;
}

void Search(int k){
	if(k > n){
		ma++;
		return;
	}
	for(int i = 1;i<=m;i++){
		B[k] = i;
		if(!hc(k)){
			A[k] = 1;
			Search(k+1);
			A[k] = 0;
		}
	}
	
}

int main(){
	int k;
	scanf("%d%d%d",&n,&k,&m);
	for(int i = 0;i<k;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		cd[u][v] = 1;
		cd[v][u] = 1;
	}
	
	Search(1);
	printf("%d\n",ma);
	return 0;
}
