#include<bits/stdc++.h>
using namespace std;
int n,k;
int x[100];//����
int x1[100];//��ҵ
int maxnum=1000000;

void task(int level)
{
    if(level>n){
     int temp=0;
     for(int i=1;i<=k;i++){
        if(x[i]>temp){
            temp=x[i];
        }
     }
     if(temp<maxnum){
        maxnum=temp;
     }
    }
    else{
        for(int i=1;i<=k;i++){
            x[i]+=x1[level];
            task(level+1);
            x[i]-=x1[level];
        }
    }
}
int main()
{
    cin >> n;
    cin >> k;
    for(int i=1;i<=n;i++){
        cin >>x1[i];
    }
    task(1);
    cout << maxnum;
    return 0;
}
