#include<bits/stdc++.h>
using namespace std;

const int M = 1000005;
int n,w;
int A[M],Q[M],ID[M];

void minquery(){
	int st = 0;
	int ed = 0;
	for(int i = 1;i<=w;i++){
		while(st<ed && Q[ed]>A[i]) ed--;
		ed++;
		Q[ed] = A[i];
		ID[ed] = i;
	}
	for(int i = w+1;i<=n;i++){
		while(st<ed && ID[st+1]<i-w) st++;
		printf("%d ",Q[st+1]);
		while(st<ed && Q[ed]>A[i]) ed--;
		ed++;
		Q[ed] = A[i];
		ID[ed] = i;
	}
	while(st<ed && ID[st+1]<n+1-w) st++;
	printf("%d\n",Q[st+1]);
}
void maxquery(){
	int st = 0;
	int ed = 0;
	for(int i = 1;i<=w;i++){
		while(st<ed && Q[ed]<A[i]) ed--;
		ed++;
		Q[ed] = A[i];
		ID[ed] = i;
	}
	for(int i = w+1;i<=n;i++){
		while(st<ed && ID[st+1]<i-w) st++;
		printf("%d ",Q[st+1]);
		while(st<ed && Q[ed]<A[i]) ed--;
		ed++;
		Q[ed] = A[i];
		ID[ed] = i;
	}
	while(st<ed && ID[st+1]<n+1-w) st++;
	printf("%d\n",Q[st+1]);
}
int main(){
	scanf("%d%d",&n,&w);
	for(int i = 1;i<=n;i++){
		scanf("%d",&A[i]);
	}
	minquery();
	maxquery();
	return 0;
}
