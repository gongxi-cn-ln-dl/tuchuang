#include<bits/stdc++.h>
using namespace std;

int stuck_[260];
int p = 1;

void push(int n){stuck_[p++] = n;}
void pop(){p--;}
int top(){return stuck_[p-1];}

int tl(char c){
	switch (c){
		case '{':{return 4;break;}
		case '<':{return 1;break;}
		case '[':{return 3;break;}
		case '(':{return 2;break;}
		case '}':{return 4;break;}
		case '>':{return 1;break;}
		case ']':{return 3;break;}
		case ')':{return 2;break;}
	}
}
bool isL(char c){
	return (c == '{' || c == '<' || c == '[' || c == '(');
}
bool check(char s[]){
	stuck_[0] = 1e9;
	p = 1;
	for(int i = 0;i<strlen(s);i++){
		if(isL(s[i])){
			if(tl(s[i])<=top()){
				push(tl(s[i]));
			}else{
				return false;
			}
		}else{
			if(tl(s[i]) == top()){
				pop();
			}else{
				return false;
			}
		}
	}
	if(p == 1) return true;

	return false;
}

int main(){
	int n;
	scanf("%d",&n);
	for(int i = 0;i<n;i++){
		char sss[500];
		scanf("%s",sss);
		printf("%s\n",check(sss)?"YES":"NO");
	}
	return 0;
}
