#include<bits/stdc++.h>
using namespace std;

int st_[50];
int pppp = 0;
void popp(){pppp--;}
int topp(){return st_[pppp-1];}
void pushh(int a){st_[pppp++] = a;}

int ppp = 0;
char yunsuanfuS[50];
int p = 1;
struct DDD{
	int mo;
	int dt;
	char f;
}A[50];

void pop(){
	A[ppp].f = yunsuanfuS[p-1];
	A[ppp].mo = 0;
	ppp++;
	if(p == 0) return;
	p--;
}
void push(char f){yunsuanfuS[p++] = f;}
char top(){return yunsuanfuS[p-1];}

int level(char c){
	if(c == '+' || c == '-') return 1;
	if(c == '*' || c == '/') return 2;
	if(c == '^') return 3;
	if(c == '(') return -1;
	return -2;
}
bool cmp(char c){
	int t1 = 0;
	int t2 = 0;
	t1 = level(c);
	t2 = level(top());
	return t1>t2;
}
int yunsuan(int a,int b,char s){
	switch(s){
		case '+':{return a+b;break;}
		case '-':{return a-b;break;}
		case '*':{return a*b;break;}
		case '/':{return a/b;break;}
		case '^':{return pow(a,b);break;}
	}
}

int main(){
	char s[50];
	scanf("%s",s);
	yunsuanfuS[0] = ' ';
	int d = 0;
	for(int i = 0;i<strlen(s);i++){
		if(isdigit(s[i])){
			d++;
			if(i == strlen(s)-1){
				int dt = 0;
				for(int j = 0;j<1;j++){
					dt = dt + (s[i-j] - '0') * pow(10,j);
				}
				A[ppp].dt = dt;
				A[ppp].mo = 1;
				ppp++;
			}
		}else{
			if(d != 0){
				int dt = 0;
				for(int j = 0;j<d;j++){
					dt = dt + (s[i-j-1] - '0') * pow(10,j);
				}
				A[ppp].dt = dt;
				A[ppp].mo = 1;
				ppp++;
				d = 0;
			}
			char c = s[i];
			if(c == ')'){
				while(top()!='(') pop();
				p--;
			}
			else if(c == '('){
				push(c);
			}
			else if(cmp(c)) push(c);
			else{
				while(!cmp(c) && top()!='(') pop();
				push(c);
			}
			
		}
	}
	while(p!=1) pop();
	int r = 0;
	for(int i = 0;i<ppp;i++){
		if(A[i].mo){
			pushh(A[i].dt);
		}else{
			int v = topp();
			popp();
			int u = topp();
			popp();

			pushh(yunsuan(u,v,A[i].f));
		}
	}
	printf("%d",st_[pppp-1]);
	return 0;
}

