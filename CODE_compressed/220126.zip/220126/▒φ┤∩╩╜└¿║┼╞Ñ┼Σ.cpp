#include<bits/stdc++.h>
using namespace std;

char stack_[50];
int p = 0;

void push(char c){stack_[p++] = c;}
void pop(){p--;}
char top(){return stack_[p-1];}

int main(){
	char s;
	while(true){
		scanf("%c",&s);
		if(s == '@') break;
		if(s != '(' && s != ')') continue;
		if(s == '(') push(s);
		else{
			if(top() == '(') pop();
			else{
				printf("NO");
				return 0;
			}
		}
	}
	if(p == 0) printf("YES");
	else{
		printf("NO");
	}
	return 0;
}
