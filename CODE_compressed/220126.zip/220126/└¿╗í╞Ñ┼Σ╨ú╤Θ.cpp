#include<bits/stdc++.h>
using namespace std;

char stack_[258];
int p = 0;

void push(char c){stack_[p++] = c;}
void pop(){p--;}
char top(){return stack_[p-1];}

int main(){
	char ss[256];
	scanf("%s",ss);
	int i = 0;
	while(i<strlen(ss)){
		char s = ss[i++];
		if(s == '(' || s == '[') push(s);
		else{
			if((top() == '(' && s == ')') || (top() == '[' && s == ']')) pop();
			else{
				printf("Wrong");
				return 0;
			}
		}
	}
	if(p == 0) printf("OK");
	else{
		printf("Wrong");
	}
	return 0;
}
