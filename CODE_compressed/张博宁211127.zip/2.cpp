#include<bits/stdc++.h>
using namespace std;

bool f(int a){
	while(a>0){
		if(a%10!=2&&a%10!=3&&a%10!=5&&a%10!=7){
			return true;
		}
		a/=10;
	}
	return false;
}
int main(){
	int A[4] = {2,3,5,7};
	int a,b,c;
	for(int i = 2222;i<=7777;i++){
		if(f(i)) continue;
		for(int j = 0;j<4;j++){
			int r = A[j] * i;
			if(f(r) || r/10000==0) continue;
			printf("%6d\nx%5d\n------\n%6d\n\n",i,A[j],r);
		}
	}
	return 0;
}
