#include<bits/stdc++.h>
using namespace std;

struct S{
	char num[5];
	float score;
}A[15];

bool cmp(S a,S b){
	return a.score > b.score;
}

int main(){
	for(int i = 0;i<14;i++){
		scanf("%s %f",&A[i].num,&A[i].score);
	}
	sort(A,A+14,cmp);
	for(int i = 1;i<=8;i++){
		printf("%d %s %.1f\n",i,A[i].num,A[i].score);
	}
	return 0;
}
//017 12.3
//168 12.6
//088 13.0
//105 11.8
//058 12.1
//123 13.1
//142 12.0
//055 11.9
//113 11.6
//136 12.4
//020 12.9
//032 13.2
//089 12.2
//010 11.4
