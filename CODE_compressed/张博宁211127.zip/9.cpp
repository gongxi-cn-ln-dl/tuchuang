#include<bits/stdc++.h>
using namespace std;

bool isS(int a){
	for(int i = 2;i*i<=a;i++){
		if(a%i==0) return false;
	}
	return true;
}
int main(){

	int A[4] = {2,3,5,7};
	for(int i = 0;i<4;i++){
		for(int j = 0;j<10;j++){
			int t = i+j*10;
			if(isS(t)){
				for(int a = 1;a<10;a++){
					if(isS(t+a*100)){
						printf("%d ",t+a*100);
					}
				}
			}
		}
	}
	return 0;
}
