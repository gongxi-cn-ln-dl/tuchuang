#include<bits/stdc++.h>
using namespace std;

int p(int a){
	int r = 1;
	for(int i = 0;i<a;i++){
		r *= 2;
	}
	return r;
}
int main(){
	int n;
	scanf("%d",&n);
	int A[255];
	int sum = 0;
	int index = 1;
	while(sum<=n){
		sum = p(index++);
	}
	printf("%d",sum/2);
	return 0;
}
