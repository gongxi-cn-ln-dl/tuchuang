#include<bits/stdc++.h>
using namespace std;

int A[105];
int B[105];

void cpy(int len){
	memset(A,0,105);
	for(int i = 0;i<len;i++){
		A[i] = B[i];
	}
}

void chengjigen(int &len){
	memset(B,0,105);
	B[0] = 1;
	for(int i = 0;i<len;i++){
		B[i] *= 
	}
}

int main(){
	string s;
	cin>>s;
	int len = s.size();
	for(int i = len-1;i>=0;i--){
		A[i] = s[len-i-1];
	}
	while(!is1(n)){
		chengjigen(n);
	}
	printf("%lld",n);
	return 0;
}
