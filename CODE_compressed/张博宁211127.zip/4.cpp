#include<bits/stdc++.h>
using namespace std;

bool isn(long long a,int n){
	int c = 0;
	while(a>0){
		c++;
		a/=10;
	}
	return n == c;
}

bool isd(long long a){
	int n[7];
	int c = 0;
	while(a>0){
		n[c++] = a%10;
		a/=10;
	}
	for(int i = 0;i<6;i++){
		for(int j = i+1;j<7;j++){
			if(n[i]==n[j]) return false;
		}
	} 
	return true;
}
int main(){
	for(int i = 1000;i<3500;i++){
		long long x = i * i;
		if(!isn(x,7)) continue;
		if(isd(x)) printf("%lld\n",x);
	}
	return 0;
}
