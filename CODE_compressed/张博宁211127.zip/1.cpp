#include<bits/stdc++.h>
using namespace std;

int main(){
	int A[35];
	int n;
	scanf("%d",&n);
	A[1] = 1;
	A[2] = 1;
	for(int i = 2;i<n;i++){
		A[0] = A[1];
		A[1] = A[2];
		A[2] = A[1] + A[0];
	}
	printf("%d",A[2]);
	return 0;
}
