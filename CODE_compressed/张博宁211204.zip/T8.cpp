#include<bits/stdc++.h>
using namespace std;

int A[10001] = {1};
int n;

void print(int t){
	for(int i = 1;i<=t-1;i++){
		printf("%d+",A[i]);
	}
	printf("%d\n",A[t]);
}
void f(int s,int t){
	for(int i = A[t-1];i<=s;i++){
		if(i<n){
			A[t] = i;
			s -= i;//ʣs��Ҫ���� 
			if(s==0) print(t);
			else f(s,t+1);
			s+=i;
		}else{
			break;
		}
	}
}
int main(){
	scanf("%d",&n);
	f(n,1);
	return 0;
}


