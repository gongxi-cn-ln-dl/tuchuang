#include<bits/stdc++.h>
using namespace std;

int n,len;
int A[9];

void f(int a,int l,int A[]){
	if(a>len){
		for(int i = 1;i<a;i++){
			printf("%d",A[i]);
		}
		printf(" ");
		return;
	}
	for(int i = l;i<=n;i++){
		A[a] = i;
		f(a+1,i+1,A);
	}
}
int main(){
	scanf("%d%d",&n,&len);
	f(1,1,A);
	return 0;
}


