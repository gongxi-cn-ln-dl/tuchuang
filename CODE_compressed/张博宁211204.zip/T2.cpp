#include<bits/stdc++.h>
using namespace std;

int main(){
	int n;
	scanf("%d",&n);
	int *A = new int[n];
	
	int ma = -1;
	int mai = -1;
	
	for(int i = 0;i<n;i++){
		scanf("%d",&A[i]); 
	}
	for(int i = 0;i<2;i++){
		ma = -1;
		for(int j = i;j<n;j++){
			if(A[j]>ma){
				mai = j;
				ma = A[j];
			}
		}
		swap(A[i],A[mai]);
	}
	printf("%d",A[1]);
	return 0;
}
