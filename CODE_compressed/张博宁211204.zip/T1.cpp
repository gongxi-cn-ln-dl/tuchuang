#include<bits/stdc++.h>
using namespace std;

int main(){
	bool A[10000];
	int a,b;
	scanf("%d%d",&a,&b);
	memset(A,true,b);
	for(int i = 2;i<=b;i++){
		for(int j = 2;j<=a;j++){
			if(i*j>b) break;
			A[i*j] = false;
		}
	}
	int sum = 0;
	for(int i = a;i<=b;i++){
		sum += A[i];
	}
	printf("%d",sum);
	return 0;
}
