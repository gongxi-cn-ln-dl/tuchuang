#include<bits/stdc++.h>
using namespace std;

int *A;

int f(int st,int ed,int x){
	if(st+1 == ed) return -1;
//	printf("%d %d \n",st,ed);
	int ti = (st+ed)/2;
	int t = A[ti];
	
	if(x == t) return ti;
	if(x > t){
		f(ti,ed,x);
	}else{
		f(st,ti,x);
	}
}
int main(){
	int n;
	scanf("%d",&n);
	A = new int[n];

	for(int i = 0;i<n;i++){
		scanf("%d",&A[i]);
	}
	int x;
	scanf("%d",&x);
	printf("%s",f(0,n-1,x)==-1?"NO":"YES");
	return 0;
}


