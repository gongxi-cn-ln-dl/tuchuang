#include<bits/stdc++.h>
using namespace std;

long long p(int a,int n){
	long long r = 1;
	for(int i = 0;i<n;i++){
		r *= a;
	}
	return r;
}
int main(){
	int x,n;
	scanf("%d%d",&x,&n);
	printf("%lld",p(x,n));
	return 0;
}


