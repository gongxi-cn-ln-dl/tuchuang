#include<bits/stdc++.h>
using namespace std;

int main(){
	string s;
	cin>>s;
	int sum = 0;
	int ma = -1;
	int q = 1;
	for(int i = s.length()-1;i>=0;i--){
		if(isdigit(s[i])){
			sum += q*(s[i]-'0');
			q *= 10;
			continue;
		}
		if(isdigit(s[i+1])){
			ma = ma>sum?ma:sum;
			sum = 0;
			q = 1;
		}
	}
	printf("%d",ma);
	return 0;
}
