#include<bits/stdc++.h>
using namespace std;

bool isz(int n){
	for(int i = 2;i<n;i++){
		if(n%i==0) return false;
	}
	return true;
}
// 36 -> 18 -> 9  -> 3  -> 1
//    2     2     3     3
void f(int n){
	if(isz(n)){
		printf("%d ",n);
		return;
	}
	for(int i = 2;i<n;i++){
		if(n%i==0 && isz(i)){
			printf("%d ",i);
			f(n/i);
			break;
		}
	}
}
int main(){
	int n;
	scanf("%d",&n);
	f(n);
	return 0;
}
