#include<bits/stdc++.h>
using namespace std;

char stack_[2000050];
char ss[200050];

int p = 0;

void push(char s) stack_[p++] = s;
void pop() p--;
char top() return stack_[p-1];

bool isL(char c){
	return (c == '(' || c == '[' || c == '{' || c == '<');
}
bool cmp(char c,char cc){
	switch(c){
		case '(':{
			return cc == ')';
			break;
		}
		case '{':{
			return cc == '}';
			break;
		}
		case '[':{
			return cc == ']';
			break;
		}
		case '<':{
			return cc == '>';
			break;
		}
	}
}

void f(){
	p = 0;
	scanf("%s",ss);
	for(int i = 0;i<strlen(ss);i++){
		char c = ss[i];
		if(isL(c)) push(c);
		else{
			if(cmp(top(),c) && p != 0){
				pop();
			}else{
				printf("FALSE\n");
				return;
			}
		}
	}
	printf("%s",p?"FALSE\n":"TRUE\n");
}

int main(){
	int n;
	scanf("%d",&n);
	for(int i = 0;i<n;i++){
		f();
	}
}
