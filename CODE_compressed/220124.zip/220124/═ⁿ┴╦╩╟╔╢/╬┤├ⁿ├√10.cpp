#include<iostream>
using namespace std;

int main(){
	short A[10];
	for(int i = 0;i<10;i++){
		cin>>A[i];
		A[i] -= 30;
	}
	short b,cnt = 0;
	cin>>b;
	for(short i = 0;i<10;i++){
		if(b >= A[i]) cnt++;
	}
	cout<<cnt<<endl;
	return 0;
}
