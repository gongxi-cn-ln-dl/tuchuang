#include<bits/stdc++.h>
using namespace std;

int stack_[500];
int p = 0;
void push(int a){stack_[p++] = a;}
void pop(){p--;}
int top(){return stack_[p-1];}

int main(){
	char s[50];
	int len = 0;
	
	char c;
	while(true){
		scanf("%c",&c);
		if(c == '@') break;
		if(c == '.'){
			int t = 0;
			for(int i = 0;i<len;i++){
				t += (pow(10,len-i-1) * (s[i]-'0'));
			}
			push(t);
			len = 0;
		}else{
			if(isdigit(c)) s[len++] = c;
			else{
				int a1 = top();
				pop();
				int a2 = top();
				pop();
//				printf("%d %c %d\n",a1,c,a2);
				switch(c){
					case '+':{push(a1+a2);break;}
					case '-':{push(a2-a1);break;}
					case '*':{push(a1*a2);break;}
					case '/':{push(a2/a1);break;}
				}
			}
		}	
	}
	printf("%d ",stack_[0]);
	
	return 0;
}
