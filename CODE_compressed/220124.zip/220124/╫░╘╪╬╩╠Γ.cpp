#include<bits/stdc++.h>
using namespace std;

int A[200000];
int B[200000];

int n,c;
int maxW = -1;

void Search(int l,int w){
	if(w>c) return; 
	for(int i = l;i<=n;i++){
		if(B[i]) continue;
		B[i] = 1;
		if(w <= c){
			maxW = max(maxW,w);
		}
		Search(i,w+A[i]);
		
		B[i] = 0;
	}
}

int main(){
	scanf("%d%d",&n,&c);
	for(int i = 0;i<n;i++){
		scanf("%d",&A[i]);
	}
	
	sort(A,A+n);
	Search(0,0);
	printf("%d",maxW);
	return 0;
}

