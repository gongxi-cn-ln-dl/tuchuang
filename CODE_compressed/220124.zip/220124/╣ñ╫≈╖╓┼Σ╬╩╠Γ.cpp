#include<bits/stdc++.h>
using namespace std;

int A[22][22];
int B[22];
int maxM = 1e9;
int n;

void Search(int k,int sum){
	if(sum > maxM) return;
	
	for(int i = 0;i<n;i++){
		if(B[i]) continue;
		B[i] = 1;
		sum += A[k][i];
		if(k == n-1){
			maxM = min(maxM,sum);
		}else{
			Search(k+1,sum);
		}
		B[i] = 0;
		sum -= A[k][i];
	}
}
int main(){
	scanf("%d",&n);
	for(int i = 0;i<n;i++){
		for(int j = 0;j<n;j++){
			scanf("%d",&A[i][j]);
		}
	}
	Search(0,0);
	printf("%d",maxM);
	return 0;
}
