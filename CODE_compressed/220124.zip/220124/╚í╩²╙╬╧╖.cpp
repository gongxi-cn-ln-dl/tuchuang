#include<bits/stdc++.h>
using namespace std;

int A[8][8];
int B[8][8];
int sumM = -1;


int T,N,M;

void fil(int x,int y,int n){
	B[x][y] = n;
	B[x+1][y] = n;
	B[x][y+1] = n;
	B[x+1][y+1] = n;
	B[x-1][y] = n;
	B[x][y-1] = n;
	B[x-1][y-1] = n;
	B[x+1][y-1] = n;
	B[x-1][y+1] = n;
}
void check(int sum){
	if(sum > sumM){
		sumM = sum;
		for(int k = 0;k<=M+1;k++){
				for(int m = 0;m<=N+1;m++){				
					printf("%d ",B[k][m]);
				}
				printf("\n");
			}
	}
}
//void cpy(int md){
//	printf("%c\n",md?'C':'P');
//	for(int i = 0;i<=M+1;i++){
//		for(int j = 0;j<=N+1;j++){
//			if(md){
//				C[i][j] = B[i][j];
//			}
//			else{
//				B[i][j] = C[i][j];
//			}
//			printf("%d",B[i][j]);
//		}
//		printf("\n");
//	}
//	printf("\n");
//}
void dfs(int x,int y,int sum){
	int C[8][8];
	if(x == M && y == N) check(sum);
	for(int i = y;i<=N;i++){
		for(int j = 1;j<=M;j++){
			if(B[i][j] == 0) continue;
			
			for(int k = 0;k<=M+1;k++){
				for(int m = 0;m<=N+1;m++){
					C[k][m] = B[k][m];
//					printf("%d ",C[k][m]);
				}
//				printf("\n");
			}
			
			fil(i,j,0);
			dfs(i,j,sum+A[i][j]);
			for(int k = 0;k<=M+1;k++){
				for(int m = 0;m<=N+1;m++){
					B[k][m] = C[k][m];
				}
			}	
		}
	}
	
}
int main(){
	scanf("%d%d%d",&T,&N,&M);
	memset(A,-1,sizeof(A));
	memset(B,0,sizeof(B));
//	memset(C,0,sizeof(C));
	for(int i = 1;i<=N;i++){
		for(int j = 1;j<=M;j++){
			scanf("%d",&A[i][j]);
			B[i][j] = 1;
		}
	}
	dfs(1,1,0);
	printf("%d",sumM);
	return 0;
}
