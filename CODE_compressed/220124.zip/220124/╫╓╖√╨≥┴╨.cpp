#include<bits/stdc++.h>
using namespace std;

int A[13];
int cnt = 0;
int N;

bool check(int l){
	for(int i = 0;i<l-3;i++){
		if(A[i] == A[i+2] && A[i+1] == A[i+3]) return true;
	}
	return false;
}

void S(int n){
//	printf("%d",n);
	if(check(n)) return;
	for(int i = 1;i<=3;i++){
		A[n] = i;
		if(n == N-1){
			if(!check(N))cnt++;
		}else{
			S(n+1);
		}
		
	}
}
int main(){
	scanf("%d",&N);
	if(N<=3){
		printf("%d",(int)pow(3,N));
		return 0;
	}
	S(0);
	printf("%d",cnt);
	return 0;
}
