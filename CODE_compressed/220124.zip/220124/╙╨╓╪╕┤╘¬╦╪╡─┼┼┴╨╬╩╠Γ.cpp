#include<bits/stdc++.h>
using namespace std;

int main(){
	int n,cnt = 1;
	cin>>n;
	char s[510];
	scanf("%s",s);
	sort(s,s+n);
	printf("%s\n",s);
	while(next_permutation(s,s+n)){
		cout<<s<<endl;
		cnt++;
	}
	
	printf("%d",cnt);
	return 0;
}
