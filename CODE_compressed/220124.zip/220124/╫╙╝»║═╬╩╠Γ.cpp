#include<bits/stdc++.h>
using namespace std;

int A[10000];
int B[10000];
int C[10000];
int D[10000];

int n,c;
int flag = 1;

void print(int k){
	for(int i = 0;i<k;i++){
		printf("%d ",C[i]);
	}
	exit(0);
}

void Search(int l,int k,int sum){
	if(k >= n) return;
	if(sum > c) return;
	if(sum == c) print(k);
	if(sum + D[l]<c) return;
	for(int i = l;i<=n;i++){
		if(B[i]) continue;
//		print(k);
		C[k] = A[i];
		Search(i+1,k+1,sum+A[i]);
	}
}

int main(){
	
//	freopen("in.in","r",stdin);
	scanf("%d%d",&n,&c);
	memset(B,0,sizeof(B));
	memset(A,0,sizeof(A));
	for(int i = 0;i<n;i++){
		scanf("%d",&A[i]);
	}
	for(int i = n-1;i>=0;i--){
		D[i] = D[i+1]+A[i];
	}
	Search(0,0,0);
	printf("No Solution!");
	return 0;
}
